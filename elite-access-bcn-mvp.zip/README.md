# Elite Access BCN

MVP PWA de gestión de servicios: fichaje, GPS, rondas, incidencias, parte diario y firma.

## Ejecutar
1. Instala Node.js LTS.
2. En esta carpeta ejecuta `npm install`
3. Ejecuta `npm run dev`
4. Abre la dirección local indicada por Vite.

## Producción
`npm run build`

El MVP funciona sin backend para demostrar la interfaz. La siguiente fase conecta Firebase:
- Authentication
- Firestore
- Storage
- Cloud Messaging
- reglas de seguridad por roles

## Importante
Antes de usarlo con trabajadores reales hay que implementar privacidad, retención de datos, controles de acceso, auditoría y cumplimiento RGPD/LOPDGDD, especialmente para localización.
