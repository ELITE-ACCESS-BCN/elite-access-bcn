import React,{useEffect,useState} from "react";
import {createRoot} from "react-dom/client";
import "./styles.css";

const demo={
  employee:{name:"Juan Pérez",role:"Vigilante / Auxiliar",service:"Centro Barcelona",status:"Fuera de servicio"},
  stats:{workers:37,onDuty:12,incidents:3,rounds:7,attendance:48}
};

function App(){
 const [tab,setTab]=useState("Inicio"),[clock,setClock]=useState(null),[gps,setGps]=useState(null),[inc,setInc]=useState([]),[report,setReport]=useState(null),[signed,setSigned]=useState(false);
 useEffect(()=>{if("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(()=>{})},[]);
 const locate=()=>navigator.geolocation?.getCurrentPosition(p=>setGps({lat:p.coords.latitude.toFixed(6),lng:p.coords.longitude.toFixed(6),acc:Math.round(p.coords.accuracy)}),e=>alert("No se pudo obtener GPS: "+e.message),{enableHighAccuracy:true});
 const fichar=()=>{locate();setClock(clock?null:new Date().toLocaleString("es-ES"));};
 const addIncident=()=>{setInc([{id:"INC-"+Date.now().toString().slice(-6),time:new Date().toLocaleTimeString("es-ES"),type:"Acceso",priority:"Media",text:"Incidencia registrada desde la app"},...inc])};
 const nav=["Inicio","Fichaje","Rondas","Incidencias","Parte diario","Perfil"];
 return <div className="app">
  <header><div><b>ELITE ACCESS</b><span>BCN · Control de servicios</span></div><div className="online">● Sistema operativo</div></header>
  <main>
   <aside>{nav.map(x=><button className={tab===x?"active":""} onClick={()=>setTab(x)} key={x}>{icon(x)} {x}</button>)}<div className="role">TRABAJADOR<br/><strong>{demo.employee.name}</strong></div></aside>
   <section className="content">
    {tab==="Inicio"&&<Dashboard clock={clock} gps={gps} inc={inc} setTab={setTab}/>}
    {tab==="Fichaje"&&<Attendance clock={clock} gps={gps} fichar={fichar}/>}
    {tab==="Rondas"&&<Rounds gps={gps} locate={locate}/>}
    {tab==="Incidencias"&&<Incidents inc={inc} add={addIncident}/>}
    {tab==="Parte diario"&&<Report clock={clock} gps={gps} signed={signed} setSigned={setSigned}/>}
    {tab==="Perfil"&&<Profile/>}
   </section>
  </main>
 </div>
}
const icon=x=>({Inicio:"⌂",Fichaje:"◷",Rondas:"◎",Incidencias:"⚠", "Parte diario":"▤",Perfil:"◯"})[x];

function Card({title,children,wide=false}){return <div className={"card "+(wide?"wide":"")}><h3>{title}</h3>{children}</div>}
function Dashboard({clock,gps,inc,setTab}){return <>
 <div className="hero"><div><small>BUENAS NOCHES</small><h1>Centro Barcelona</h1><p>Servicio activo · Control operativo</p></div><button onClick={()=>setTab("Fichaje")} className="primary">{clock?"✓ Fichaje activo":"Fichar entrada"}</button></div>
 <div className="grid stats"><Card title="Trabajadores"><strong>37</strong><span> registrados</span></Card><Card title="En servicio"><strong>12</strong><span> ahora</span></Card><Card title="Incidencias"><strong>{3+inc.length}</strong><span> abiertas</span></Card><Card title="Rondas"><strong>7</strong><span> activas</span></Card></div>
 <div className="grid two"><Card title="Mi servicio"><div className="row"><span>Estado</span><b className="ok">{clock?"● En servicio":"○ Fuera de servicio"}</b></div><div className="row"><span>Fichaje</span><b>{clock||"Pendiente"}</b></div><div className="row"><span>GPS</span><b>{gps?`✓ ${gps.acc} m`:"No verificado"}</b></div></Card>
 <Card title="Acciones rápidas"><div className="actions"><button onClick={()=>setTab("Fichaje")}>◷ Fichaje</button><button onClick={()=>setTab("Rondas")}>◎ Iniciar ronda</button><button onClick={()=>setTab("Incidencias")}>⚠ Incidencia</button><button onClick={()=>setTab("Parte diario")}>▤ Parte diario</button></div></Card></div>
 </>}
function Attendance({clock,gps,fichar}){return <><h1>Fichaje</h1><p className="muted">Registro de entrada y salida asociado al servicio.</p><Card title="Servicio actual"><div className="service"><div><b>Centro Barcelona</b><span>Vigilancia / control de accesos</span></div><span className={clock?"badge green":"badge"}>{clock?"EN SERVICIO":"FUERA DE SERVICIO"}</span></div><div className="clock">{clock||"—"}</div><button className="primary big" onClick={fichar}>{clock?"Fichar salida":"Fichar entrada"}</button>{gps&&<p className="gps">✓ GPS verificado · {gps.lat}, {gps.lng} · precisión {gps.acc} m</p>}</Card></>}
function Rounds({gps,locate}){const [active,setActive]=useState(false),[points,setPoints]=useState([]); const scan=()=>{locate();setPoints([...points,{n:points.length+1,time:new Date().toLocaleTimeString("es-ES")}])}; return <><h1>Rondas</h1><p className="muted">Control por puntos con hora y posición GPS.</p><Card title="Ronda nocturna · Centro Barcelona"><div className="service"><b>{active?"Ronda en curso":"Ronda preparada"}</b><span>{points.length}/5 puntos</span></div>{!active?<button className="primary big" onClick={()=>{setActive(true);locate()}}>Iniciar ronda</button>:<><div className="points">{[1,2,3,4,5].map(n=><div className="point" key={n}><b>Punto {n}</b><span>{points.find(p=>p.n===n)?`✓ ${points[n-1].time}`:"Pendiente"}</span></div>)}</div>{points.length<5?<button className="primary" onClick={scan}>Registrar punto GPS</button>:<button className="primary" onClick={()=>setActive(false)}>Finalizar ronda</button>}</>}</Card></>}
function Incidents({inc,add}){return <><h1>Incidencias</h1><p className="muted">Registra hechos y evidencias del servicio.</p><Card title="Nueva incidencia"><button className="primary" onClick={add}>＋ Registrar incidencia de prueba</button><p className="muted small">En la versión conectada se añadirán fotos, audio, ubicación, prioridad y firma.</p></Card><Card title="Últimas incidencias">{inc.length===0?<p className="muted">No hay incidencias creadas en esta sesión.</p>:inc.map(i=><div className="incident" key={i.id}><b>{i.id}</b><span>{i.time} · {i.type} · {i.priority}</span><p>{i.text}</p></div>)}</Card></>}
function Report({clock,gps,signed,setSigned}){return <><h1>Parte diario</h1><p className="muted">Resumen del servicio listo para cerrar y firmar.</p><Card title="Parte #DEMO-001"><div className="report"><p><b>Cliente:</b> Centro Barcelona</p><p><b>Trabajador:</b> Juan Pérez</p><p><b>Servicio:</b> Vigilancia / control de accesos</p><p><b>Fecha:</b> {new Date().toLocaleDateString("es-ES")}</p><p><b>Fichaje:</b> {clock||"Pendiente"}</p><p><b>GPS:</b> {gps?"Verificado":"Pendiente"}</p><label>Observaciones<textarea placeholder="Escribe las observaciones del servicio..."/></label></div>{signed?<div className="signed">✓ Parte firmado y preparado para PDF</div>:<button className="primary" onClick={()=>setSigned(true)}>✍ Firmar y cerrar parte</button>}</Card></>}
function Profile(){return <><h1>Mi perfil</h1><Card title="Datos profesionales"><div className="profile"><div className="avatar">JP</div><div><h2>Juan Pérez</h2><p>Vigilante / Auxiliar de servicios</p><p className="muted">ID empleado: E-00037</p></div></div></Card><Card title="Seguridad"><p>✓ Cuenta protegida</p><p>✓ Acceso por rol</p><p>✓ Registro de actividad preparado</p></Card></>}
createRoot(document.getElementById("root")).render(<App/>);
